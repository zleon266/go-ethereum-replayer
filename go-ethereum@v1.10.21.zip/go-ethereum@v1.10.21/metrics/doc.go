package metrics

const epsilon = 0.0000000000000001
const epsilonPercentile = .00000000001
